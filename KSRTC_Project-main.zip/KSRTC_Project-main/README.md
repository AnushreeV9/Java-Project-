# KSRTC_Project 🚌
 
### KSRTC wants to improve its bus services by easing the process of ticket booking and maintaining the records of drivers, conductors, passengers. 
* Bus is characterised by number of the bus, type of the bus, number of seats, bus owner, etc.
* Bus travels from one source to destination and in between has halts at various stands as per the schedule. 
* Bus schedule is dynamic in the sense that it may have different source and destinations with varied routes on a given day. 
* Each bus stand is characterised by location, terminals number, type of stand, etc. Thus the travel route and details of the passengers travelled needs to be maintained. 
* A passenger can book a ticket apriori or on the spot by boarding the bus provided seat is available. 
* The ticket information is also to be maintained for future requirements. 




